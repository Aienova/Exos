public class Exo1 {
    public static void main(String[] args) throws Exception {

        /* Déclaration de la variable */
        String x = "Bonjour";

        /* Affiche la variable x */
        System.out.println(x);
    }
}
