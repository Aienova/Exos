public class Exo3 {
    public static void main(String[] args) throws Exception {

        /*Déclaration des variables en chaîne de caractères */

        String pronom = "Je ";  
        String verbe = "s'appelle";
        String prenom = " Groot ";

        /* Concaténation des chaînes de caractères */
        String result = pronom + verbe + prenom;
        
        System.out.println(result);
    }
}
