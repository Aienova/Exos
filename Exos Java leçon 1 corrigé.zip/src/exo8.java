public class exo8 {


    /*  EXERCICE 8 : Créer un algorithme qui convertit un kg en pounds ( c'est une unité de mesure anglo-saxonne) */

    public static void main(String[] args) throws Exception {

        double kg = 80.00;

        double lbs = kg * 2.20462;

        System.out.println("Conversion kilogramme en pounds de "+kg+"kg vaut "+lbs+"lbs");


    }

        /*  Résultat Attendu : 80 kg vaut 176,37 Lbs */

}
