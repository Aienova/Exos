


public class exo10Simple {

        /*  EXERCICE 10 (Version original) : Créer un algorithme qui convertit n'importe qu'elle valeurs binaires en Hexadécimal */

        public static void main(String[] args) throws Exception {

   
      System.out.println();

        }

                    /*  Résultat Attendu : 1010 en binaire vaut A en Hexa */

}
