public class exo5 {
    public static void main(String[] args) throws Exception {

        /*Exo 5 : Calculer prix d'une réduction de -20% */

        System.out.println();



        /* Resultat attendu :
         * 
         * 
         * 100€ après une réduction de -20% vaut 80€
         * 
         */
    }
}
