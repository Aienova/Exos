public class exo7 {


    /*  EXERCICE 7 : Convertir des jours au format année | mois | jours , note on ne prendra pas en compte les années bixestiles */

    public static void main(String[] args) throws Exception {


        System.out.println();


    }

    
    /*  Résultat Attendu : 365 jour vaut : 1 année , 0 mois et 0 jour */

}
