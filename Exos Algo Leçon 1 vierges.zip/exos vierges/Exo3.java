public class Exo3 {
    public static void main(String[] args) throws Exception {

        /*Exo 3 : Déclarer 3 valariable contenant les 3 mots suivant : "Je" "m'appelle" "(Votre Prénom)" et les faire afficher  */

        System.out.println("");
    }
}
