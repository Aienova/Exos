public class exo8 {


    /*  EXERCICE 8 : Créer un algorithme qui convertit un kg en pounds ( c'est une unité de mesure anglo-saxonne) */

    public static void main(String[] args) throws Exception {



        System.out.println("");


    }

        /*  Résultat Attendu : 80 kg vaut 176,37 Lbs */

}
