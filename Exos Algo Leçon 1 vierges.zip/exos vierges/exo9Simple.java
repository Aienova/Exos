public class exo9Simple {


    /*  EXERCICE 9 (Version original): Créer un algorithme qui convertit n'importe qu'elle valeurs décimal (entier) en binaire */

    public static void main(String[] args) throws Exception {



    System.out.println();



    }

            /*  Résultat Attendu : 1 en décimal vaut 0001 en binaire */
}
