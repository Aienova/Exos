public class exo6 {



    /*  EXERCICE 6 : Créer un convertisseur de secondes au format Heures : Minutes : secondes */

    public static void main(String[] args) throws Exception {


        System.out.println();



    }

    /*  Résultat Attendu : 60 secondes vaut : 0 heure : 1 minute : 0 seconde */


}
