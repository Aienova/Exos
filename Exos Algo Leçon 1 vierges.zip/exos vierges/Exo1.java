public class Exo1 {
    public static void main(String[] args) throws Exception {

        /* Exo 1 : Faire afficher le mot Bonjour avec une variable */

        System.out.println();
    }
}
