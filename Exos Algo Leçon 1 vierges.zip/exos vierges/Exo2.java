public class Exo2 {
    public static void main(String[] args) throws Exception {

        /*Exo 2 : Déclaration des variables deux variable entiers, les additionner et afficher sa somme */

        System.out.println("");
    }
}
