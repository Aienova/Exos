public class Exo4 {

    public static void main(String[] args) throws Exception {

        /*Exo 3 : Déclarer 3 valariable contenant les 3 mots suivant : "Je" "m'appelle" "(Votre Prénom)" et ajouter son âge puis l'afficher  */

 


        
        System.out.println("");

        
        /* Résultat attendu : Je m'appelle (Votre prénom) , j'ai 32 ans */
    }

}
